import edu.princeton.cs.algs4.Digraph;
import edu.princeton.cs.algs4.BreadthFirstDirectedPaths;

import java.io.IOException;
import java.util.ArrayList;

public class Outcast {
	private final WordNet words;
	// constructor takes a WordNet object
	   public Outcast(WordNet wordnet) {
		   words = wordnet;
	   }
	// given an array of WordNet nouns, return an outcast
	   public String outcast(String[] nouns) {
		   int N = nouns.length;
	        int[][] dist = new int[N][N];
	        
	        // calculate all distance combinations and store them
	        for(int i = 0; i < N-1; i++) {
	            dist[i][i] = 0;
	            for(int j = i+1; j < N; j++) {
	                dist[i][j] = words.distance(nouns[i], nouns[j]);
	                dist[j][i] = dist[i][j];
	            }            
	        }
	        
	        // calculate sum of colums for each row and report the row with max sum
	        int maxSum = -1;
	        int maxID = -1;        
	        for (int i = 0; i < N; i++) {
	            int sum = 0;
	            for (int j = 0; j < N; j++) {
	                sum += dist[i][j];
	            }
	            
	            if (sum > maxSum) {
	                maxSum = sum;
	                maxID = i;
	            }            
	        }
	        
	        return nouns[maxID];
	    }
	// see test client below
//	   public static void main(String[] args) {
//		   WordNet w = new WordNet("synsets.txt", "hypernyms.txt");
//		   Outcast o = new Outcast(w);
//		   Iterable<String> s = w.nouns();
//		   ArrayList<String> List = new ArrayList<String>();
//		   for(String i : s) {
//			   List.add(i);
//		   }
//		   String[] nouns = new String[List.size()];
//		   for (int i =0; i < List.size(); i++) {
//	            nouns[i] = List.get(i); 
//		   }
//		   System.out.println("mmmm");
//		   System.out.println(o.outcast(nouns));
//	   }
	}
